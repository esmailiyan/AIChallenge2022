rm -rf dist
rm -rf build
rm client.spec
pyinstaller --onefile src/client.py
