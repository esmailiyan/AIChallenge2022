from src import model
from src.model import GameView

class Graph:
    def __init__(self, view: GameView) -> None:
        '''----- config structures -----'''
        self.adj = {}
        self.degree = {}
        self.nodes = []
        self.edges = []
        self.prices = []
        '''----- handle nodes -----'''
        for N in view.config.graph.nodes:
            self.nodes.append(N.id)
        '''----- handle nodes -----'''
        self.prices = [[-1 for _ in range(257)] for _ in range(257)]
        for E in view.config.graph.paths:
            self.edges.append((E.first_node_id, E.second_node_id, E.price))
            self.prices[E.first_node_id][E.second_node_id] = self.prices[E.second_node_id][E.first_node_id] = E.price
        '''----- handle data -----'''
        for v in self.nodes:
            self.adj[v] = []
        for (v, u, w) in self.edges:
            self.adj[v].append((u, w))
            self.adj[u].append((v, w))
        '''----- config degree -----'''
        for v in self.nodes:
            self.degree[v] = len(self.adj[v])
        '''----- sort edges -----'''
        for v in self.nodes:
            self.adj[v].sort(key=lambda e: [e[1], -self.degree[e[0]]])

    def find_path(self, start: int, target: int, without=[], prices=[0, 25, 50]) -> list:
        '''----- config structures -----'''
        list = []
        mark = {}
        parent = {}
        '''----- config data -----'''
        for v in self.nodes:
            mark[v] = False
            parent[v] = -1
        '''----- config setup -----'''
        list.append(start)
        mark[start] = True
        parent[start] = 0
        '''----- start bfs -----'''
        for v in list:
            for (u, w) in self.adj[v]:
                if not mark[u] and w in prices and u not in without:
                    mark[u] = True
                    parent[u] = v
                    list.append(u)
        '''----- find path -----'''
        ans = []
        pt = target
        while pt > 0:
            ans.append(pt)
            pt = parent[pt]
        ans.reverse()
        return ans
        
    def bfs(self, start: int, prices=[0,25,50]) -> list:
        arr = [1e5 for _ in range(257)]
        visited = [False for _ in range(257)]

        que = [start]
        arr[start] = 0
        visited[start] = True
        
        for v in que:
            for (u, w) in self.adj[v]:
                if not visited[u] and w in prices:
                    visited[u] = True
                    arr[u] = arr[v]+1
                    que.append(u)
        
        return arr

    def find_dist(self, start: int, target: int, prices=[0, 25, 50]) -> int:
        return len(self.find_path(start=start, target=target, prices=prices))-1

    def get_path_price(self, u :int, v :int) -> float:
        return self.prices[u][v]