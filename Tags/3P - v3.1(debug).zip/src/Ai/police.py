import enum
import random
from dis import dis
from pydoc import visiblename
from readline import append_history_file
from tabnanny import check

from src.Ai.massage import Massage
from src.Ai.phone import Phone
from src.Ai.unit import Unit
from src.Ai.utils import Utils
from src.model import AgentType, GameView, Team, Turn, Graph


class Police(Unit):

    def __init__(self, view: GameView, phone: Phone) -> None:
        super().__init__(view, phone)
        self.target = -1
        self.path = []

    def move(self, view :GameView):
        if view.turn in view.visible_agents:
            thiefs = self.filter_agents(view, not view.viewer.team, AgentType.THIEF.value)
            if len(thiefs) > 0:
                dist = self.bfs(view.viewer.node_id)
                
                # get nearest thief:
                self.target = -1
                mn = 1e9
                for thief in thiefs:
                    if dist[thief.node_id] < mn:
                        mn = dist[thief.node_id]
                        self.target = thief.node_id

                self.phone(Massage.encode_msg(self.target, view.balance))
                return self.f(view=view)

        if len(self.path) > 0:
            node = self.path[0]
            self.path.pop(0)
            return node

        # get farthest node from node 1:
        dist = self.bfs(view.viewer.node_id)
        self.target = 1
        mx = dist[1]
        for i in range(2, 257):
            if dist[i] > mx:    
                mx = dist[i]
                self.target = i

        polices = self.filter_agents(view=view, team=not view.viewer.team, agentType=AgentType.POLICE.value)
        alist = [view.viewer.id]
        for p in polices:  
            if p.node_id == view.viewer.node_id:    alist.append(p.id)

        alist.sort()
        index = 0
        for i in range(len(alist)):
            if alist[i] == view.viewer.id:
                index = i
                break

        nodes_wiegth = [0 for _ in range(257)]

        self.path = []
        for _ in range(index):
            for a in self.path:
                d = self.bfs(a, 0)
                for i in range(len(d)):
                    if d[i] <= Graph.Police_Vision:   nodes_wiegth += Graph.Police_Vision - d[i]

            self.path = self.dijkstra(view.viewer.id, self.target, nodes_wiegth)
        
        node = self.path[0]
        Utils.log(f'police {view.viewer.id}: choosen path={str(self.path)}')
        self.path.pop(0)
        return node

    def f(self, view: GameView):
        self.update_info(view)
        
        if self.search_in_neighbor(view) != 0:   return self.search_in_neighbor(view)

        t = self.target   
        self.target = self.update_target(view=view)
        Utils.log(f'police {view.viewer.id}: target has updated from {t} to {self.target}')

        dist = self.bfs(self.target)
        dist_me = self.bfs(view.viewer.node_id)
        
        alist = []
        for i in range(1, len(dist)+1): alist.append(i)

        alist.sort(key=lambda x: val(x, self.adj[x]))

        partners = [view.viewer.id]
        filter = {"team": view.viewer.team, "type": view.viewer.agent_type, "dead": False, "node": view.viewer.node_id}
        for agent in view.visible_agents:
            check = {"team": agent.team, "type": agent.agent_type, "dead": agent.is_dead, "node": agent.node_id}
            if filter == check: partners.append(agent.id)

        partners.sort()
        index = 0
        for i in range(len(partners)):
            if partners[i] == view.viewer.id:   
                index = i
                break

        def val(x :int, adj :list) -> int:
            v = 0
            for i in adj:
                v += -(dist[i]/dist_me[i])

            v += -(dist[x]/dist_me[x])
        return self.go(view=view, node=alist[index%len(alist)])

    def update_target(self, view: GameView) -> int:
        thiefs = self.filter_agents(view=view, team=not view.viewer.team, agentType=AgentType.THIEF.value)

        if len(thiefs) == 0:    
            Utils.log(f"police {view.viewer.id}: there is no thief! err in police.py/line 70")
            return -1

        # get theif with min id (this algorithm shall change):
        res = None
        for theif in thiefs:
            if theif.is_dead:   continue
            if res is None or theif.id < res.id:    res = theif

        if res is None:
            Utils.log(f"police {view.viewer.id}: there is no thief! err in police.py/line 70")
            return -1

        return res.node_id

    def choose_priority(self, view :GameView, dist=[]) -> None:
        if dist == []:  dist = self.bfs(view.viewer.node_id)
        data = f'police {view.viewer.id}: choosing priority \n' 
        self.pri_nodes[0] = self.block_metro_node(self.target, view=view, dist=dist)
        self.pri_nodes[1] = self.block_taxi_node(self.target, view=view, dist=dist)
        self.pri_nodes[2] = self.catch_thief_node(view=view, thief_node=self.target)
        mx = 0
        for i in range(3):
            if self.pri_nodes[i] == -1: 
                data += f'{i} node={self.pri_nodes[i]}, dist={dist[self.pri_nodes[i]]}, val={-1/dist[self.pri_nodes[i]]}\n'
                continue

            data += f'{i} node={self.pri_nodes[i]}, dist={dist[self.pri_nodes[i]]}, val={(3-i)/dist[self.pri_nodes[i]]}\n'
            if mx < (3-i)/dist[self.pri_nodes[i]]:
                mx = (3-i)/dist[self.pri_nodes[i]]
                self.priority = i

        data += f'choosen pri={self.priority}'
        Utils.log(data)
        if mx == 0: 
            self.priority = -1
            Utils.log(f"priority set to -1 in police.py/line 86, command from police {view.viewer.id}")
        
    def block_metro_node(self, thief_node :int, view :GameView, dist=[]) -> int:
        metro_nodes = []
        for a in self.graph.adj[thief_node]:
            if self.prices[a][thief_node] == 50:    metro_nodes.append(a)

        if len(metro_nodes) == 0:   return -1
        if dist == []:  dist = self.bfs(self.node_id)

        # chosing node with min distance, 
        # maybe this algorithm goas wrong for lack of money
        res = []
        mn = 1e9
        for a in metro_nodes:
            if dist[a] == mn:   res.append(a)
            if dist[a] < mn:
                res.clear()
                res.append(a)
                mn = dist[a]
        
        if len(res) == 0:
            Utils.log(f'sth goas wrong in police.py/line 92: res list is empty! command called by police: {view.viewer.id}')
            return -1
        # choosing randomally:
        return res[2*view.viewer.id %len(res)]

    def block_taxi_node(self, thief_node :int, view :GameView, dist=[]) -> int:
        taxi_nodes = []
        for a in self.graph.adj[thief_node]:
            if self.prices[a][thief_node] == 25:    taxi_nodes.append(a)

        if len(taxi_nodes) == 0:   return -1
        if dist == []:  dist = self.bfs(self.node_id)

        # chosing node with min distance, 
        # maybe this algorithm goas wrong for lack of money
        res = []
        mn = 1e9
        for a in taxi_nodes:
            if dist[a] == mn:   res.append(a)
            if dist[a] < mn:
                res.clear()
                res.append(a)
                mn = dist[a]
        
        if len(res) == 0:
            Utils.log(f'sth goas wrong in police.py/line 121: res list is empty! command called by police {view.viewer.id}')
            return -1
        # choosing randomally:
        return res[2*view.viewer.id %len(res)]

    def catch_thief_node(self, view :GameView, thief_node :int) -> int:
        return thief_node

    def passing_thief_node(self) -> int:
        pass

    def spreading(self, view :GameView):
        adj_count = len(self.adj)
        node = self.adj[2*view.viewer.id %adj_count]
        if self.prices[self.node_id][node] > self.balance: 
            for i in self.adj:
                if self.prices[self.node_id][i] < self.balance: return i
        return node

    def search_in_neighbor(self, view :GameView) -> int:
        thiefs = self.filter_agents(view=view, team=not view.viewer.team, agentType=AgentType.THIEF.value)

        for a in self.adj:
            if a in thiefs: 
                return a
        return 1

    def send_massage(self, text :str):
        self.phone.send_message(text)