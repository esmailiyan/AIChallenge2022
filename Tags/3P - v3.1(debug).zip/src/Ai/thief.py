from ctypes import util
from email import utils
import queue
from typing import List
from src import model
from src.Ai.phone import Phone
from src.Ai.unit import Unit
from src.Ai.utils import Utils
from src.client import GameClient
from src.hide_and_seek_pb2 import BATMAN
from src.model import GameView


class Thief(Unit):

    def predict(self, adj, police_nodes, batman_node, degree):
        queue = []
        visited = [False for _ in range(257)]
        parent = [0 for _ in range(257)]
        predict = [0 for _ in range(257)]

        for p in police_nodes:
            predict[p] = 100
            parent[p] = 0
            visited[p] = True
            queue.append(p)
        for b in batman_node:
            predict[b] = 100
            parent[b] = 0
            visited[b] = True
            queue.append(b)

        for v in queue:
            for (u, w) in adj[v]:
                if not visited[u]:
                    visited[u] = True
                    parent[u] = v
                    predict[u] = predict[v]/degree[v]
                    queue.append(u)

        return predict
        

    def move(self, view: GameView) -> int:
        id = view.viewer.id
        team = view.viewer.team
        type = view.viewer.agent_type
        is_dead = view.viewer.is_dead
        balance = view.balance
        status = view.status
        node_id = view.viewer.node_id
        turn_id = view.turn.turn_number
        chat_box = view.chat_box
        visible_agents = view.visible_agents
        visible_turns = view.config.visible_turns

        adj = self.graph.adj
        node = self.graph.nodes
        degree = self.graph.degree

        police_nodes = self.filter_agents(view=view, team=not team, agentType=model.AgentType.POLICE.value)
        Utils.log(f"turn:{turn_id:<3}, thief:{id:<4}, SUCCESS FIELD 1 , police_nodes:{str(police_nodes)}")
        batman_node = self.filter_agents(view=view, team=not team, agentType=model.AgentType.BATMAN.value)
        Utils.log(f"turn:{turn_id:<3}, thief:{id:<4}, SUCCESS FIELD 2 , batman_node:{str(batman_node)}")
        predict = self.predict(adj, police_nodes, batman_node, degree)
        Utils.log(f"turn:{turn_id:<3}, thief:{id:<4}, SUCCESS FIELD 3 , predict:{str(predict)}")

        move_flag = False
        bfs_list = self.bfs(node_id, 0)
        for p in police_nodes:
            move_flag |= (bfs_list[p] <= model.Graph.Police_Vision)

        if not move_flag:   return node_id

        neighbors = []
        for (u, w) in adj[node_id]:
            neighbors.append(u)
        neighbors.sort(key=lambda x: predict[x])
        return neighbors[0]