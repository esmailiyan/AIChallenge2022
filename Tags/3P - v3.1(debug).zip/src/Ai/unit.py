from src.Ai.graph import Graph
from src.Ai.massage import Massage
from src.Ai.phone import Phone
from src.Ai.utils import Utils
from src.model import Agent, AgentType, GameView, Team

class Unit:
    def __init__(self, view :GameView, phone :Phone) -> None:
        self.phone = phone
        self.view = view
        self.graph = Graph(view=view)
        self.target = -1

    def filter_agents(self, view :GameView, team :Team, agentType :AgentType) -> list:
        ans = list()
        filter = {"team": team, "type": agentType, "dead": False}
        for a in view.visible_agents:
            check = {"team": a.team, "type": a.agent_type, "dead": a.is_dead}
            if filter == check:
                ans.append(a.node_id)
        return ans

    def bfs(self, my_node, max_price=1e3) -> list:
        arr = [1e5 for _ in range(257)]
        visited = [False for _ in range(257)]

        que = []
        que.append(my_node)
        arr[my_node] = 0
        visited[my_node] = True
        
        node = int()
        while len(que) != 0:
            node = que.pop(0)
            adj = self.graph.adj[node]
            for (a, w) in adj:
                if visited[a] or w > max_price:  continue
                arr[a] = arr[node]+1
                visited[a] = True
                que.append(a)

        return arr

    def is_visible_turn(self, view :GameView) -> bool:
        return self.turn in view.config.visible_turns