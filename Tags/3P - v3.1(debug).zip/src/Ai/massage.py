from src.Ai.utils import Utils
from src.model import Chat, GameView

class Massage:
    def decode_msg(msg: str) -> int:
        try:
            data = int(msg, base=2)
            return data
        except:
            Utils.log(f"Error in decode_msg! -> msg={msg}")

    def encode_msg(msg: int) -> str:
        try:
            data = format(msg, "b")
            return data
        except:
            Utils.log(f"Error in encode_msg! -> msg={msg}")


