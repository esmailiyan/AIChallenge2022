from pydoc import visiblename
from src.Ai.graph import Graph
from src.Ai.massage import Massage
from src.Ai.phone import Phone
from src.Ai.utils import Utils
from src.model import Agent, AgentType, GameView, Team
from src.datastructure.binaryHeap import BinaryHeap

class Unit:
    def __init__(self, view :GameView, phone :Phone) -> None:
        self.phone = phone
        self.view = view
        self.graph = Graph(view=view)
        self.target = 0
        self.last_msg = -1

    def filter_agents(self, view :GameView, team :Team, agentType :AgentType) -> list:
        ans = list()
        filter = {"team": team, "type": agentType, "dead": False}
        for a in view.visible_agents:
            check = {"team": a.team, "type": a.agent_type, "dead": a.is_dead}
            if filter == check:
                ans.append(a.node_id)
        return ans

    def bfs(self, my_node, max_price=1e3) -> list:
        arr = [1e5 for _ in range(257)]
        visited = [False for _ in range(257)]

        que = []
        que.append(my_node)
        arr[my_node] = 0
        visited[my_node] = True
        
        node = int()
        while len(que) != 0:
            node = que.pop(0)
            adj = self.graph.adj[node]
            for (a, w) in adj:
                if visited[a] or w > max_price:  continue
                arr[a] = arr[node]+1
                visited[a] = True
                que.append(a)

        return arr


    def dijkstra(self, home :int, goal :int, nodes_wiegth=[]) -> list:        
        if nodes_wiegth == []:  nodes_wiegth = [0 for _ in range(self.graph.node_count+1)]

        visited = [False for _ in range(self.graph.node_count +1)]
        arr = [1e9 for _ in range(self.graph.node_count +1)]
        parent = [0 for _ in range(self.graph.node_count +1)]
        heap = BinaryHeap()

        parent[home] = home
        arr[home] = 0
        heap.add((nodes_wiegth[home], home))

        while heap.size() != 0:
            (node, val) = heap.front()
            heap.remove()

            if visited[node]:   continue
            visited[node] = True

            if node == goal:    break
            for (a, w) in self.graph.adj[node]:
                v = val + w + nodes_wiegth[node]
                if v < arr[a]:
                    arr[a] = v
                    parent[a] = node
                    heap.add((v, a))
                    

        
        ans = []
        node = goal
        while parent[goal] != goal:
            ans.append(node)
            node = parent[node]

        ans.reverse()
        return ans


    def is_visible_turn(self, view :GameView) -> bool:
        return self.turn in view.config.visible_turns

    def decode_msg(self, msg: str) -> int:
        try:
            data = int(msg, base=2)
            return data
        except:
            Utils.log(f"Error in decode_msg! -> msg={msg}")

    def encode_msg(self, msg: int) -> str:
        try:
            data = format(msg, "b")
            return data
        except:
            Utils.log(f"Error in encode_msg! -> msg={msg}")


    def update_msg(self) -> list:
        chat_box = self.view.chat_box
        chat_box.reverse()
        msg = []
        for m in chat_box:
            if m.id == self.last_msg:   break
            msg.append(self.decode_msg(msg=m.text))

        self.last_msg = chat_box[0].id
        return 
        

    def visible_turn_passed_count(self, turn :int) -> int:
        t = self.view.turn
        visible_turn = self.view.config.visible_turns

        count = 0
        for a in visible_turn:
            if a < turn:    continue
            if a > t:   break
            count += 1

        return count

