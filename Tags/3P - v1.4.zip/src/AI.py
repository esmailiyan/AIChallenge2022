import random
from src.client import GameClient
from src.model import GameView

def get_thief_starting_node(view: GameView) -> int:
    nodes = view.config.graph.nodes
    a = []
    for n in nodes:
        if a != 1:
            a.append(n.id)
    random.shuffle(a)
    return a[0]

class Utils:
    def log(data: str) -> bool:
        addr = "/home/mahdi/Documents/AIC22-Client-Python/log.txt"
        try: 
            with open(addr, "a") as file:
                file.write(data + '\n')   
            return True
        except:
            return False

class Message:
    def decode_msg(msg: str) -> int:
        try:
            data = int(msg, base=2)
            return data
        except:
            Utils.log(f"Error in decode_msg! -> msg={msg}")
    def encode_msg(msg: int) -> str:
        try:
            data = format(msg, "b")
            return data
        except:
            Utils.log(f"Error in encode_msg! -> msg={msg}")

class Graph:
    def __init__(self, Edges, Nodes):
        '''----- config structures -----'''
        self.adj = {}
        self.degree = {}
        self.nodes = []
        self.edges = []
        self.thief_nodes = []
        '''----- handle nodes -----'''
        for N in Nodes:
            self.nodes.append(N.id)
        '''----- handle nodes -----'''
        for E in Edges:
            self.edges.append((E.first_node_id, E.second_node_id, E.price))
        '''----- handle data -----'''
        for v in self.nodes:
            self.adj[v] = []
        '''----- config graph -----'''
        for (v, u, w) in self.edges:
            self.adj[v].append((u, w))
            self.adj[u].append((v, w))
        '''----- config degree -----'''
        for v in self.nodes:
            self.degree[v] = len(self.adj[v])
        '''----- sort edges -----'''
        for v in self.nodes:
            self.adj[v].sort(key=lambda e: e[1])
    
    def find_path(self, start: int, target: int, prices=[0, 25, 50]):
        '''----- config structures -----'''
        list = []
        mark = {}
        parent = {}
        '''----- config data -----'''
        for v in self.nodes:
            mark[v] = False
            parent[v] = -1
        '''----- config setup -----'''
        list.append(start)
        mark[start] = True
        parent[start] = 0
        '''----- start bfs -----'''
        for v in list:
            for (u, w) in self.adj[v]:
                if not mark[u] and w in prices:
                    mark[u] = True
                    parent[u] = v
                    list.append(u)
        '''----- find path -----'''
        ans = []
        pt = target
        while pt > 0:
            ans.append(pt)
            pt = parent[pt]
        return ans

    def update_thief_nodes(self):
        '''----- config structures -----'''
        list = []
        mark = {}
        '''----- config data -----'''
        for v in self.nodes:
            mark[v] = False
        '''----- start bfs -----'''
        for v in self.thief_nodes:
            list.append(v)
            mark[v] = True
            for (u, w) in self.adj[v]:
                if not mark[u]:
                    mark[u] = True
                    list.append(u)
        '''----- update data -----'''
        self.thief_nodes = list

class Phone:
    def __init__(self, client: GameClient):
        self.client = client

    def send_message(self, message):
        self.client.send_message(message)

class AI:
    def __init__(self, phone: Phone):
        self.phone = phone

    def thief_move_ai(self, view: GameView) -> int:
        '''----- config -----'''

        id = view.viewer.id
        team = view.viewer.team
        type = view.viewer.agent_type
        is_dead = view.viewer.is_dead
        balance = view.balance
        status = view.status
        node_id = view.viewer.node_id
        turn_id = view.turn.turn_number
        chat_box = view.chat_box
        visible_agents = view.visible_agents
        visible_turns = view.config.visible_turns

        '''----- make & config graph -----'''

        if turn_id == 1:
            self.graph = Graph(view.config.graph.paths, view.config.graph.nodes)
        adj = self.graph.adj
        node = self.graph.nodes
        degree = self.graph.degree

        '''----- find visible enemy -----'''

        police_node = []
        filter = {"team": not team, "type": not type, "dead": False}
        for a in visible_agents:
            check = {"team": a.team, "type": a.agent_type, "dead": a.is_dead}
            if filter == check:
                police_node.append(a.node_id)

        danger_node = []
        for p in police_node:
            for (u, w) in adj[p]:
                if u not in danger_node:
                    danger_node.append(u)

        '''----- sort & list neighbor nodes -----'''

        for v in node:
            adj[v].sort(key=lambda e: [e[1], -degree[e[0]]])

        neighbor = []
        for (u, w) in adj[node_id]:
            neighbor.append(u)

        '''------ get run ------'''

        # Utils.log(f"turn{turn_id} , thief({id}):\n--suspect node: -\n--neigghbor node: {str(adj[node_id])}\n--degree node: {str(degree[node_id])}\n")
        for n in neighbor:
            if n not in police_node and n not in danger_node:
                return n
        return neighbor[0]

        '''------ end code ------'''

    def police_move_ai(self, view: GameView) -> int:
        '''----- config -----'''

        id = view.viewer.id
        team = view.viewer.team
        type = view.viewer.agent_type
        is_dead = view.viewer.is_dead
        balance = view.balance
        status = view.status
        node_id = view.viewer.node_id
        turn_id = view.turn.turn_number
        chat_box = view.chat_box
        visible_agents = view.visible_agents
        visible_turns = view.config.visible_turns

        '''----- make & config graph -----'''

        if turn_id == 2:
            self.graph = Graph(view.config.graph.paths, view.config.graph.nodes)
            self.mark = []
        adj = self.graph.adj
        node = self.graph.nodes
        degree = self.graph.degree

        '''----- find visible enemy -----'''

        if turn_id in visible_turns:
            self.graph.thief_nodes = []
            filter = {"team": not team, "type": not type, "dead": False}
            for a in visible_agents:
                check = {"team": a.team, "type": a.agent_type, "dead": a.is_dead}
                if filter==check:
                    self.graph.thief_nodes.append(a.node_id)

        '''----- find live partner -----'''

        partners = []
        filter = {"team": team, "type": type, "dead": False}
        for a in visible_agents:
            check = {"team": a.team, "type": a.agent_type, "dead": a.is_dead}
            if filter==check:
                partners.append(a.node_id)

        '''----- scan enemy location -----'''

        enemy = []
        for ver in self.graph.thief_nodes:
            path = self.graph.find_path(node_id, ver)
            path.reverse()
            if path not in enemy:
                enemy.append(path)
        enemy.sort(key=lambda x: len(x))
        if enemy.count([node_id]):
            enemy.remove([node_id])

        '''----- scan neighbor nodes -----'''

        for v in node:
            adj[v].sort(key=lambda e: [e[1], -degree[e[0]]])

        neighbor = []
        for (u, w) in adj[node_id]:
            if w == 0: 
                neighbor.append(u)

        '''----- config move -----'''

        move = []
        if len(enemy) > 0:
            for e in enemy:
                if len(e) > 1:
                    move.append(e[1])
                else:
                    move.append(e[0])
        else:
            for n in neighbor:
                move.append(n)
            random.shuffle(move)

        '''----- config node mark -----'''

        if turn_id in visible_turns:
            self.mark = []
        for p in partners:
            if p not in self.mark:
                self.mark.append(p)
        self.mark.append(node_id)

        '''------ get run ------'''

        # Utils.log(f"turn{turn_id} , police({id}):\n--enemy paths: {str(enemy)}\n--neighbors: {str(neighbor)}\n--partner location: {str(partners)}\n--marked location: {str(set(self.mark))}\n")
        for m in move:
            if m not in self.mark:
                return m
        random.shuffle(move)
        return move[0]

        '''------ end code ------'''
