

class Utils:

    def log(data :str) -> bool:
        addr = "/home/mahdi/Documents/AIC22-Client-Python-test/log.txt"
        try:
            with open(addr, "a") as file:
                file.write(data + '\n')
                return True

        except:
            return False