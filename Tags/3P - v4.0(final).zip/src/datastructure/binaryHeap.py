
from select import select


class BinaryHeap:
    
    def __init__(self) -> None:
        self.heap = []
    
    
    def front(self):
        return self.heap[0]

    def less(self, i :int, j :int) -> bool: 
        if self.heap[i][0] == self.heap[j][0]:
            return self.heap[i][1] < self.heap[j][1]

        return self.heap[j][0] < self.heap[j][0]


    def swap(self, i :int, j :int):
        self.heap[i], self.heap[j] = self.heap[j], self.heap[i]


    def swim(self, k :int):
        parent = (k-1)/2

        while (k > 0 and self.less(k, parent)):
            self.swap(parent, k)

            k = parent
            parent = (k-1)/2


    def sink(self, k :int):
        
        while (True):
            right = 2*k +2
            left = 2*k +1
            smallest = left

            if (left >= len(self.heap) or self.less(k, left)):
                break

            if (right < len(self.heap) and self.less(right, left)):  
                smallest = right

            self.swap(smallest, k)
            k = smallest

    
    ''' remove 0 index '''
    def remove(self):
        self.swap(0, len(self.heap)-1)
        self.heap.pop()
        
        self.sink(0)
        


    def add(self, elem):
        self.heap.append(elem)
        self.swim(len(self.heap)-1)


    def __str__(self) -> str:
        return str(self.heap)    
