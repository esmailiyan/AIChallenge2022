from src import model
from src.Ai.unit import Unit
from src.Ai.utils import Utils
from src.client import GameClient
from src.hide_and_seek_pb2 import BATMAN
from src.model import GameView


class Thief(Unit):

    def predict(self, adj, polices, batman, partners, joker, degree):
        queue = []
        visited = [False for _ in range(257)]
        predict = [0 for _ in range(257)]

        for p in polices:
            predict[p] = 0
            visited[p] = True
            queue.append(p)
        for b in batman:
            predict[b] = 0
            visited[b] = True
            queue.append(b)

        for v in queue:
            for (u, w) in adj[v]:
                if not visited[u]:
                    visited[u] = True
                    if w == 0:  predict[u] = predict[v] + 1.0
                    if w == 25:  predict[u] = predict[v] + 1.25
                    if w == 50:  predict[u] = predict[v] + 1.50
                    if u in joker: predict[u] -= 2
                    if u in partners: predict[u] -= 1
                    predict[u] += degree[u]/10
                    queue.append(u)

        return predict
        
    def move(self, view: GameView) -> int:
        id = view.viewer.id
        team = view.viewer.team
        type = view.viewer.agent_type
        is_dead = view.viewer.is_dead
        balance = view.balance
        status = view.status
        node_id = view.viewer.node_id
        turn_id = view.turn.turn_number
        chat_box = view.chat_box
        visible_agents = view.visible_agents
        visible_turns = view.config.visible_turns

        adj = self.graph.adj
        node = self.graph.nodes
        degree = self.graph.degree
        prices = self.graph.prices

        polices = self.filter_agents(view=view, team=not team, agentType=model.AgentType.POLICE.value)
        # Utils.log(f"turn:{turn_id:<3}, thief:{id:<4}, SUCCESS FIELD 1 , polices:{str(polices)}")
        batman = self.filter_agents(view=view, team=not team, agentType=model.AgentType.BATMAN.value)
        # Utils.log(f"turn:{turn_id:<3}, thief:{id:<4}, SUCCESS FIELD 2 , batman:{str(batman)}")
        partners = self.filter_agents(view=view, team=team, agentType=model.AgentType.THIEF.value)
        # Utils.log(f"turn:{turn_id:<3}, thief:{id:<4}, SUCCESS FIELD 3 , partners:{str(partners)}")
        joker = self.filter_agents(view=view, team=team, agentType=model.AgentType.JOKER.value)
        # Utils.log(f"turn:{turn_id:<3}, thief:{id:<4}, SUCCESS FIELD 4 , joker:{str(joker)}")
        predict = self.predict(adj, polices, batman, partners, joker, degree)
        # Utils.log(f"turn:{turn_id:<3}, thief:{id:<4}, SUCCESS FIELD 5 , predict:{str(predict)}")

        move_flag = False
        bfs_list = self.graph.bfs(node_id, [0])
        for p in polices:
            move_flag |= (bfs_list[p] <= model.Graph.Police_Vision)
            for (u, w) in adj[node_id]:
                if p == u: move_flag = True

        if move_flag:
            neighbors = [u for (u, w) in adj[node_id]]
            neighbors.sort(key=lambda x: predict[x], reverse=True)
            for n in neighbors:
                if prices[node_id][n] <= balance:
                    return n
        else:
            return node_id