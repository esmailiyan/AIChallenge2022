import random
from src import model
from src.Ai.phone import Phone
from src.Ai.massage import Massage
from src.Ai.unit import Unit
from src.Ai.utils import Utils
from src.client import GameClient
from src.hide_and_seek_pb2 import BATMAN, Agent
from src.model import AgentType, GameView

class Police(Unit):

    def __init__(self, view: GameView, phone: Phone) -> None:
        super().__init__(view, phone)
        self.target = 0
        self.enemys = set()
        self.path = []
        self.mark = []
        self.target_turn = 0

    def predict(self, adj, partners, target, degree) -> list: 
        queue = []
        visited = [False for _ in range(257)]
        predict = [0 for _ in range(257)]

        predict[target] = 0
        visited[target] = True
        queue.append(target)

        for v in queue:
            for (u, w) in adj[v]:
                if not visited[u]:
                    visited[u] = True
                    if w == 0:  predict[u] = predict[v] + 1.0
                    if w == 25:  predict[u] = predict[v] + 1.25
                    if w == 50:  predict[u] = predict[v] + 1.50
                    if u in partners: predict[u] += 2
                    predict[u] -= degree[u]/100
                    queue.append(u)

        return predict
      
    def move(self, view :GameView):
        self.view = view
        id = view.viewer.id
        team = view.viewer.team
        type = view.viewer.agent_type
        is_dead = view.viewer.is_dead
        balance = view.balance
        status = view.status
        node_id = view.viewer.node_id
        turn_id = view.turn.turn_number
        chat_box = view.chat_box
        visible_agents = view.visible_agents
        visible_turns = view.config.visible_turns

        adj = self.graph.adj
        node = self.graph.nodes
        degree = self.graph.degree
        prices = self.graph.prices

        msgs = self.update_msg()

        partners = self.filter_agents(view=view, team=team, agentType=model.AgentType.POLICE.value)
        # Utils.log(f"turn:{turn_id:<3}, police:{id:<4}, SUCCESS FIELD 1 , polices:{str(partners)}")
        batman = self.filter_agents(view=view, team=team, agentType=model.AgentType.BATMAN.value)
        # Utils.log(f"turn:{turn_id:<3}, police:{id:<4}, SUCCESS FIELD 2 , batman:{str(batman)}")
        thiefs = self.filter_agents(view=view, team=not team, agentType=model.AgentType.THIEF.value)
        # Utils.log(f"turn:{turn_id:<3}, police:{id:<4}, SUCCESS FIELD 3 , thiefs:{str(thiefs)}")
        joker = self.filter_agents(view=view, team=not team, agentType=model.AgentType.JOKER.value)
        # Utils.log(f"turn:{turn_id:<3}, police:{id:<4}, SUCCESS FIELD 4 , joker:{str(joker)}")
        if turn_id in visible_turns:
            self.mark = [node_id]
            self.enemys = set()
            for t in thiefs:    self.enemys.add(t)
            for j in joker:    self.enemys.add(j)

        if len(msgs):
            for m in msgs:  self.enemys.add(m)

        for p in partners:    self.mark.append(p)
        for b in batman:    self.mark.append(b)

        self.mark.append(node_id)
       
        if len(self.enemys):
            dist = []
            for enemy in self.enemys:
                val = self.graph.find_dist(node_id, enemy)
                for p in partners:    val += self.graph.find_dist(p, enemy)
                for b in batman:    val += self.graph.find_dist(b, enemy)
                dist.append((val, enemy))
            dist.sort(key=lambda x:[x[0], x[1]])

            self.target = dist[0][1]
            Utils.log(data=f"turn:{turn_id}, police:{id}, dist={str(dist)}")


            if self.target not in msgs:
                message = self.encode_msg(self.target)
                Utils.log(data=f"turn:{turn_id}, police:{id}, target={self.target}, msg={message}")
                self.phone.send_message(message=message)
                
        if self.target:
            # predict = self.predict(adj, partners, self.target, degree)
            # neighbors = [u for (u, w) in adj[node_id]]
            # neighbors.sort(key=lambda x: predict[x], reverse=False)
            path = self.graph.find_path(node_id, self.target)
            Utils.log(f"{self.target} {str(path)}")
            if len(path) > 1:    
                return path[1]
            else:
                self.target = 0
                return node_id
            # for n in neighbors:
            #     if prices[node_id][n] <= balance:
            #         return n
            # return node_id
        else:
            neighbors = [u for (u, w) in adj[node_id] if w in [0, 25]]
            random.shuffle(neighbors)
            for n in neighbors:
                if n not in self.mark and prices[node_id][n] <= balance:
                    return n
            return neighbors[0]