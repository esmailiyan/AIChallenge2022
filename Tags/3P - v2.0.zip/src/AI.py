import random
from src.client import GameClient
from src.model import GameView

def get_thief_starting_node(view: GameView) -> int:
    nodes = view.config.graph.nodes
    a = []
    for n in nodes:
        if a != 1:
            a.append(n.id)
    random.shuffle(a)
    return a[0]

class Utils:
    def log(data: str) -> bool:
        addr = "/home/mahdi/Documents/AIC22-Client-Python/log.txt"
        try: 
            with open(addr, "a") as file:
                file.write(data + '\n')   
            return True
        except:
            return False

class Message:
    def decode_msg(msg: str) -> int:
        try:
            data = int(msg, base=2)
            return data
        except:
            Utils.log(f"Error in decode_msg! -> msg={msg}")
    def encode_msg(msg: int) -> str:
        try:
            data = format(msg, "b")
            return data
        except:
            Utils.log(f"Error in encode_msg! -> msg={msg}")

class Graph:
    def __init__(self, Edges, Nodes):
        '''----- config structures -----'''
        self.adj = {}
        self.degree = {}
        self.nodes = []
        self.edges = []
        '''----- handle nodes -----'''
        for N in Nodes:
            self.nodes.append(N.id)
        '''----- handle nodes -----'''
        for E in Edges:
            self.edges.append((E.first_node_id, E.second_node_id, E.price))
        '''----- handle data -----'''
        for v in self.nodes:
            self.adj[v] = []
        '''----- config graph -----'''
        for (v, u, w) in self.edges:
            self.adj[v].append((u, w))
            self.adj[u].append((v, w))
        '''----- config degree -----'''
        for v in self.nodes:
            self.degree[v] = len(self.adj[v])
        '''----- sort edges -----'''
        for v in self.nodes:
            self.adj[v].sort(key=lambda e: [e[1], -self.degree[e[0]]])

    def find_path(self, start: int, target: int, prices=[0, 25, 50]):
        '''----- config structures -----'''
        list = []
        mark = {}
        parent = {}
        '''----- config data -----'''
        for v in self.nodes:
            mark[v] = False
            parent[v] = -1
        '''----- config setup -----'''
        list.append(start)
        mark[start] = True
        parent[start] = 0
        '''----- start bfs -----'''
        for v in list:
            for (u, w) in self.adj[v]:
                if not mark[u] and w in prices:
                    mark[u] = True
                    parent[u] = v
                    list.append(u)
        '''----- find path -----'''
        ans = []
        pt = target
        while pt > 0:
            ans.append(pt)
            pt = parent[pt]
        ans.reverse()
        return ans

    def find_dist(self, start: int, target: int, prices=[0, 25, 50]):
        path = self.find_path(start, target, prices)
        return len(path)

class Phone:
    def __init__(self, client: GameClient):
        self.client = client

    def send_message(self, message):
        self.client.send_message(message)

class AI:
    def __init__(self, phone: Phone):
        self.phone = phone

    def thief_move_ai(self, view: GameView) -> int:
        '''----- config -----'''

        id = view.viewer.id
        team = view.viewer.team
        type = view.viewer.agent_type
        is_dead = view.viewer.is_dead
        balance = view.balance
        status = view.status
        node_id = view.viewer.node_id
        turn_id = view.turn.turn_number
        chat_box = view.chat_box
        visible_agents = view.visible_agents
        visible_turns = view.config.visible_turns

        '''----- make & config graph -----'''

        if turn_id == 1:
            self.graph = Graph(view.config.graph.paths, view.config.graph.nodes)
        adj = self.graph.adj
        node = self.graph.nodes
        degree = self.graph.degree

        '''----- find visible enemy -----'''

        police_node = []
        filter = {"team": not team, "type": not type, "dead": False}
        for a in visible_agents:
            check = {"team": a.team, "type": a.agent_type, "dead": a.is_dead}
            if filter == check:
                police_node.append(a.node_id)

        danger_node = []
        for p in police_node:
            for (u, w) in adj[p]:
                if u not in danger_node:
                    danger_node.append(u)
        danger_node.sort(key=lambda x: -degree[x])
        
        '''----- sort & list neighbors nodes -----'''

        neighbors = []
        for (u, w) in adj[node_id]:
            neighbors.append(u)

        '''------ get run ------'''

        # Utils.log(f"turn{turn_id} , thief({id}):\n--suspect node: -\n--neigghbor node: {str(adj[node_id])}\n--degree node: {str(degree[node_id])}\n")
        for n in neighbors:
            if n not in police_node and n not in danger_node:
                return n
        return danger_node[0]

        '''------ end code ------'''

    def police_move_ai(self, view: GameView) -> int:
        '''----- config -----'''

        id = view.viewer.id
        team = view.viewer.team
        type = view.viewer.agent_type
        is_dead = view.viewer.is_dead
        balance = view.balance
        status = view.status
        node_id = view.viewer.node_id
        turn_id = view.turn.turn_number
        chat_box = view.chat_box
        visible_agents = view.visible_agents
        visible_turns = view.config.visible_turns

        '''----- make & config graph -----'''

        if turn_id == 2:
            self.thief_nodes = []
            self.graph = Graph(view.config.graph.paths, view.config.graph.nodes)
        adj = self.graph.adj
        node = self.graph.nodes
        degree = self.graph.degree

        '''----- update enemy location -----'''

        if turn_id in visible_turns:
            # گرفتن موقعیت دزد های حریف
            self.thief_nodes = []
            filter = {"team": not team, "type": not type, "dead": False}
            for agents in visible_agents:
                check = {"team": agents.team, "type": agents.agent_type, "dead": agents.is_dead}
                if filter == check:
                    self.thief_nodes.append(agents.node_id)
        else:
            # آپدیت نود های احتمالی که دزدای حریف میتونن برن (نود های دورتر)
            tmp = []
            for thief in self.thief_nodes:
                for (u, w) in adj[thief]:
                    if self.graph.find_dist(node_id, u) >= self.graph.find_dist(node_id, thief):
                        if u not in tmp:
                            tmp.append(u)
            for t in tmp:
                if t not in self.thief_nodes:
                    self.thief_nodes.append(t)

        '''----- find live partner -----'''

        # گرفتن موقعیت پلیس های خودی
        partners = []
        filter = {"team": team, "type": type, "dead": False}
        for a in visible_agents:
            check = {"team": a.team, "type": a.agent_type, "dead": a.is_dead}
            if filter == check:
                partners.append(a.node_id)

        '''----- scan neighbors nodes -----'''

        neighbors = []
        adj[node_id].sort(key=lambda x: [x[1], -x[0]])
        for (u, w) in adj[node_id]:
            neighbors.append(u)

        '''----- config paths -----'''

        # اضافه کردن مسیر ها به تارگت
        options = []
        for n in neighbors:
            for thief in self.thief_nodes:
                path = self.graph.find_path(n, thief)
                if path not in options:
                    options.append(path)
        options.sort(key=lambda x: len(x))

        '''----- config move -----'''

        move = []
        if len(options) > 0:
            for e in options:
                move.append(e[0])
        else:
            for n in neighbors:
                move.append(n)
        
        '''------ get run ------'''

        # Utils.log(f"turn{turn_id} , police({id}):\n--enemy paths: {str(enemy)}\n--neighbors: {str(neighbors)}\n--partner location: {str(partners)}\n--marked location: {str(set(self.mark))}\n")
        for m in move:
            if m not in partners:
                return m
        return move[0]

        '''------ end code ------'''
