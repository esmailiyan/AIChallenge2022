rm -r dist, build, client.spec, log.txt
touch log.txt
pyinstaller --onefile src/client.py