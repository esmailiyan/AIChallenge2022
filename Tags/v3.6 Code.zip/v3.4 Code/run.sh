rm -r /home/mahdi/Codes/AIC22-Server/logs/server.log
java -jar 