from cmath import phase
import imp
from src import model
from src.Ai.graph import Graph
from src.Ai.police import Police
from src.Ai.thief import Thief
from src.Ai.phone import Phone
from src.client import GameClient
from src.hide_and_seek_pb2 import AgentType
from src.model import GameView

def get_thief_starting_node(view: GameView) -> int:
    id = view.viewer.id
    graph = Graph(view)
    nodes = graph.nodes
    nodes.sort(key=lambda x: graph.degree[x], reverse=True)
    id = id%5
    return nodes[id]

# class Phone:
#     def __init__(self, client: GameClient):
#         self.client = client

#     def send_message(self, message):
#         self.client.send_message(message)

class AI:
    def __init__(self, view: GameView, phone: Phone):
        self.phone = phone
        self.unit = None

    def thief_move_ai(self, view: GameView) -> int:
        if self.unit is None:   
            self.unit = Thief(view=view, phone=self.phone)
        return self.unit.move(view=view)

    def police_move_ai(self, view: GameView) -> int:
        if self.unit is None:   
            self.unit = Police(view=view, phone=self.phone)
        return self.unit.move(view=view)
