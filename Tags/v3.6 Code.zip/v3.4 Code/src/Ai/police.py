from pydoc import visiblename
from re import S
from src import model
from src.Ai.phone import Phone
from src.Ai.massage import Massage
from src.Ai.unit import Unit
from src.Ai.utils import Utils
from src.client import GameClient
from src.hide_and_seek_pb2 import BATMAN, Agent
from src.model import AgentType, GameView


class Police(Unit):

    def __init__(self, view: GameView, phone: Phone) -> None:
        super().__init__(view, phone)
        self.target = 0
        self.enemys = []
        self.path = []
        self.mark = []
        self.target_turn = 0

    def predict(self, adj, partners, target, degree) -> list: 
        queue = []
        visited = [False for _ in range(257)]
        predict = [0 for _ in range(257)]

        predict[target] = 0
        visited[target] = True
        queue.append(target)

        for v in queue:
            for (u, w) in adj[v]:
                if not visited[u]:
                    visited[u] = True
                    if w == 0:  predict[u] = predict[v] + 1.0
                    if w == 25:  predict[u] = predict[v] + 1.25
                    if w == 50:  predict[u] = predict[v] + 1.50
                    if u in partners: predict[u] += 2
                    predict[u] -= degree[u]/100
                    queue.append(u)

        return predict
      
    def move(self, view :GameView):
        self.view = view

        id = view.viewer.id
        team = view.viewer.team
        type = view.viewer.agent_type
        is_dead = view.viewer.is_dead
        balance = view.balance
        status = view.status
        node_id = view.viewer.node_id
        turn_id = view.turn.turn_number
        chat_box = view.chat_box
        visible_agents = view.visible_agents
        visible_turns = view.config.visible_turns

        adj = self.graph.adj
        node = self.graph.nodes
        degree = self.graph.degree
        prices = self.graph.prices

        msgs = self.update_msg()

        partners = self.filter_agents(view=view, team=team, agentType=model.AgentType.POLICE.value)
        # Utils.log(f"turn:{turn_id:<3}, police:{id:<4}, SUCCESS FIELD 1 , polices:{str(partners)}")
        batman = self.filter_agents(view=view, team=team, agentType=model.AgentType.BATMAN.value)
        # Utils.log(f"turn:{turn_id:<3}, police:{id:<4}, SUCCESS FIELD 2 , batman:{str(batman)}")
        thiefs = self.filter_agents(view=view, team=not team, agentType=model.AgentType.THIEF.value)
        # Utils.log(f"turn:{turn_id:<3}, police:{id:<4}, SUCCESS FIELD 3 , thiefs:{str(thiefs)}")
        joker = self.filter_agents(view=view, team=not team, agentType=model.AgentType.JOKER.value)
        # Utils.log(f"turn:{turn_id:<3}, police:{id:<4}, SUCCESS FIELD 4 , joker:{str(joker)}")

        if self.visible_turn_passed_count(self.target_turn) >= 2:   
            self.target = 0


        if turn_id in visible_turns:
            self.mark = [node_id]
            self.enemys = []
            for t in thiefs:    self.enemys.append(t)
            for j in joker:    self.enemys.append(j)


        if len(msgs):
            for m in msgs:  self.enemys.append(m)
        #     self.target = self.decode_msg(chat_box[-1].text)
        #     if self.target:    self.enemys.append(self.target)

        

        for p in partners:    self.mark.append(p)
        for b in batman:    self.mark.append(b)

        # if len(thiefs):
        #     if self.target not in thiefs: 
        #         self.target = thiefs[0] 
        #         message = self.encode_msg(self.target)
        #         Utils.log(data=f"turn:{turn_id}, police:{id}, target={self.target}, msg={message}")
        #         self.phone.send_message(message=message)
        # elif len(joker):
        #     if self.target not in joker:
        #         self.target = joker[0]
        #         message = self.encode_msg(self.target)
        #         Utils.log(data=f"turn:{turn_id}, police:{id}, target={self.target}, msg={message}")
        #         self.phone.send_message(message=message)
        
        if len(self.enemys):
            # choosing best enemy
            alist = [self.bfs(node_id)]
            for p in partners:
                alist.append(self.bfs(p))
            
            mn = 1e9
            for enemy in self.enemys:
                val = 0
                for dist in alist:  val += dist[enemy]
                if val and val < mn:
                    self.target = enemy
                    mn = val


            if self.target == 0:    
                Utils.log(data=f"sth went wrong in police.py/line 111, called by police id={view.viewer.id}")
                return self.searching()


            self.target_turn = turn_id

            # end

            if self.target not in msgs:
                message = self.encode_msg(self.target)
                Utils.log(data=f"turn:{turn_id}, police:{id}, target={self.target}, msg={message}")
                self.phone.send_message(message=message)


            path = self.graph.find_path(node_id, self.target)
            
            return path[1] if len(path) > 1 else node_id

                  
                

                
            # neighbors = [u for (u, w) in adj[node_id]]
            # predict = self.predict(adj, partners, self.target, degree)
            # neighbors.sort(key=lambda x: predict[x], reverse=False)
        else:
            return self.searching()
            # neighbors = [u for (u, w) in adj[node_id] if w in [0, 25]]
            # neighbors.sort(key=lambda x: degree[x], reverse=True)
        

        # for n in neighbors:
        #     if n not in self.mark and prices[node_id][n] <= balance:
        #         return n
        # else:
        #     return neighbors[0]



    def searching(self) -> int:
        # get farthest node from police node:
        dist = self.bfs(self.view.viewer.node_id)
        goal = [1]
        mx = dist[1]
        for i in range(1, 257):
            if dist[i] == mx:   goal.append(i)
            if dist[i] > mx:    
                mx = dist[i] 
                goal = [i]

        
        repition = 1
        if len(goal) == 1: 
            polices = self.filter_agents(view=self.view, team=self.view.viewer.team, agentType=AgentType.POLICE.value)
            repition = 1
            for police in polices:
                if police == self.view.viewer.id:   repition += 1


        goal = goal[2*self.view.viewer.id%len(goal)]

        nodes_wiegth = [0 for _ in range(self.graph.node_count() +1)]

        path = []
        for _ in range(repition):
            for a in path:
                d = self.bfs(a, 0)
                for i in range(1, len(d)):
                    if d[i] <= model.Graph.Police_Vision:   nodes_wiegth += model.Graph.Police_Vision - d[i]

            path = self.dijkstra(self.view.viewer.id, self.target, nodes_wiegth)


        return path[0]

        

        #     if self.target:
        #     predict = self.predict(adj, partners, self.target, degree)
        #     # Utils.log(f"turn:{turn_id:<3}, police:{id:<4}, SUCCESS FIELD 5 , predict:{str(predict)}")
        #     neighbors = [u for (u, w) in adj[node_id]]
        #     neighbors.sort(key=lambda x: predict[x], reverse=False)
        #     for n in neighbors:
        #         if prices[node_id][n] <= balance:
        #             return n
        #     return node_id
        # else:
        #     neighbors = [u for (u, w) in adj[node_id] if w == 0]
        #     neighbors.sort(key=lambda x: degree[x], reverse=True)
        #     for n in neighbors:
        #         if n not in self.mark and prices[node_id][n] <= balance:
        #             return n
        #     return node_id